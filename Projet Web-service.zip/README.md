# Mamadou-Moustapha-S-ne-Alioune-Badara-Diop_Projet-Webservice
Bonjour Monsieur,
Veuillez recevoir ci-joint notre projet de WebService

Nous voulions vous informer que nous avons bien réussi à finaliser la partie REST du projet. Tout fonctionne correctement de ce côté-là. Par contre, nous avons eu des difficultés avec la partie SOAP. Malgré nos efforts et les recherches que nous avons faites, nous n’avons pas réussi à la faire fonctionner comme prévu.


Merci pour votre compréhension.

Cordialement,
